import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class HTMLPaser2014302580147 {
	
	//��ȡHTML�ĵ�������һ��Document����
	public Document getDocument (File input){
		try{
			return Jsoup.parse(input,"UTF-8");
		}catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
