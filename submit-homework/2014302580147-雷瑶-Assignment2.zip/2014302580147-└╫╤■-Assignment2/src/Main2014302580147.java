import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580147 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriter fw;
		File file = new File("Staff.txt");
		try{
			fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			
			//����getDocument()������һ��Document����doc
			HTMLPaser2014302580147 h = new HTMLPaser2014302580147();
			File myFile=new File("Staff.html");
			Document doc = h.getDocument(myFile);
		
			//��selectѡ�������н���
			
			Elements staff = doc.select("[class=details col-md-10 col-sm-9 col-xs-7]");
			//����
			Elements elements1 = staff.select("h3");
			String name = elements1.get(0).text();
			bw.write(name+"\r\n"+"\r\n");
			
			//��Ϣ
			Elements elements2 = staff.select("p");
			String info = elements2.get(0).text();
			//�����������ʽ
			//title
			Pattern p1 = Pattern.compile("��ʿ , ����");
			Matcher m1 = p1.matcher(info);
			if(m1.find()) { 
				bw.write(m1.group()+"\r\n");
			} 				
			//field
			Pattern p2 = Pattern.compile("�о����� �绯ѧ��Դ��ѧ�뼼��");
			Matcher m2 = p2.matcher(info);
			if(m2.find()) { 
				bw.write(m2.group()+"\r\n");
			} 		
			//tele
			Pattern p3 = Pattern.compile("��ϵ�绰��");
			Matcher m3 = p3.matcher(info);
			if(m3.find()) { 
				bw.write(m3.group());		     
			} 
			Pattern p4 = Pattern.compile("0\\d{2}-\\d{8}");
			Matcher m4 = p4.matcher(info);
			if(m4.find()) { 
				bw.write(m4.group()+"\r\n");
			} 
			//e-mail
			Pattern p5 = Pattern.compile("[A-Z][a-z]*: \\w+@\\w{3}\\.\\w{3}\\.\\w{2}");
			Matcher m5 = p5.matcher(info);
			if(m5.find()) { 
				bw.write(m5.group()+"\r\n"+"\r\n"+"\r\n");
			} 

			//���	
			Elements detail = doc.select("[class=szll_wz]");		
			Elements brief = doc.select("[class=szll_wz_bt]");
			Elements details = detail.select("p");
			//�������о�����
			String brief0 = brief.get(0).text();
			String details0 = details.get(1).text();
			bw.write(brief0+"\r\n");
			bw.write(details0+"\r\n"+"\r\n");
			//�о���������Ȥ
			String brief1 = brief.get(1).text();
			String details1 = details.get(2).text();
			bw.write(brief1+"\r\n");
			bw.write(details1+"\r\n"+"\r\n");
			//ѧ����ְ
			String brief2 = brief.get(2).text();
			String details2 = details.get(3).text();
			String[] ss =details2.split(" ");
			bw.write(brief2+"\r\n");
			bw.write(ss[0]+"\r\n");
			bw.write(ss[1]+" "+ss[2]+" "+ss[3]+" "+ss[4]+" "+ss[5]+" "+ss[6]+"\r\n");
			bw.write(ss[7]+" "+ss[8]+" "+ss[9]+" "+ss[10]+" "+ss[11]+"\r\n");		
		
			bw.close();
			fw.close();
			} catch (IOException e){
				e.printStackTrace();
			}
		}

}
